import tkinter as tk
from client.interfaz_usuario import Frame, barra_menu

def main():
    root = tk.Tk()
    root.title('Tostadas Mayo')
    root.iconbitmap()
    root.resizable(0,1) #para que la pantalla se pueda agrandar 
    
    barra_menu(root)  
    app = Frame(root=root) 
    app.mainloop()


if __name__ == '__main__':
    main()
