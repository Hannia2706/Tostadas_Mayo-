from .conexion_db import ConexionDB
from tkinter import messagebox

def crear_tabla():
    #realizar la conexion a la base de datos
    conexion = ConexionDB()

    sql = '''
    CREATE TABLE producto(
    nombre VARCHAR(50),
    cantidad INTEGER, 
    precio_may REAL,
    precio_men REAL,
    descripcion TEXT, 
    PRIMARY KEY(nombre)
    )'''
    try: 
        #para ejecutar el sql 
        conexion.cursor.execute(sql)
        #cerramos 
        conexion.cerrar()
        titulo = 'Crear Registro'
        mensaje = 'Se creo la tabla en la base de datos'
        #mostrar que se pudo hacer la tabla 
        messagebox.showinfo(titulo,mensaje)
    except:
        conexion.cerrar()
        titulo = 'Crear Registro'
        mensaje = 'La tabla ya está creada'
        #mostrar que se pudo hacer la tabla 
        messagebox.showwarning(titulo,mensaje)
        

def borrar_tabla():
    conexion = ConexionDB()

    #codigo para borrar la tabla de producto
    sql = 'DROP TABLE producto'
    try: 
        conexion.cursor.execute(sql)
        conexion.cerrar()
        titulo = 'Borrar Registro'
        mensaje = 'La tabla de la base de dados se borró con éxito'
        messagebox.showwarning(titulo,mensaje)
    except:
        titulo = 'Borrar Registro'
        mensaje = 'No hay tabla para borrar'
        messagebox.showerror(titulo,mensaje)

class producto:
    #constructor
    def __init__(self, nombre, cantidad, precio_may, precio_men, descripcion):
        self.nombre = nombre
        self.cantidad = cantidad
        self.precio_may = precio_may
        self.precio_men = precio_men
        self.descripcion = descripcion
    #estado del objeto 

    def __str__(self):
        return f'Producto[{self.nombre},{self.cantidad},{self.precio_may},{self.precio_men},{self.descripcion}]'
    
#ingresar o guardar datos
def guardar(producto):
    #para guardar en la base de datos, conectamos
    conexion = ConexionDB()

    sql = f"""INSERT INTO producto (nombre, cantidad, precio_may, precio_men, descripcion)
    VALUES ('{producto.nombre}', {producto.cantidad}, {producto.precio_may}, {producto.precio_men}, '{producto.descripcion}')"""

    try:
        conexion.cursor.execute(sql)
        conexion.cerrar()
    except:
        titulo = 'Conexión al registro'
        mensaje = 'La tabla de producto no está creado en la base de datos'
        messagebox.showerror(titulo,mensaje)

def listar():
    conexion = ConexionDB()

    #recuperar todos los registro de la tabla

    lista_productos = []
    sql = 'SELECT * FROM producto'

    try:
        conexion.cursor.execute(sql)
        #recuperamos toda informacion con fetchall
        lista_productos=conexion.cursor.fetchall()
        conexion.cerrar()
    #si la tabla no existe
    except:
        titulo = 'Conexión al registro'
        mensaje = 'Crea la tabla en la base de datos'
        messagebox.showwarning(titulo,mensaje)

    return lista_productos

def editar(producto , id_producto):
    conexion = ConexionDB()

    sql = f"""UPDATE producto
    SET nombre = '{producto.nombre}',
        cantidad = {producto.cantidad},
        precio_may = {producto.precio_may},
        precio_men = {producto.precio_men},
        descripcion = '{producto.descripcion}'
    WHERE id_producto = '{id_producto}"""

    try:
        conexion.cursor.execute(sql)
        conexion.cerrar()

    except:
        titulo = 'Edición de datos'
        mensaje = 'No se ha podidio editar este registro'
        messagebox.showerror(titulo,mensaje)



        
