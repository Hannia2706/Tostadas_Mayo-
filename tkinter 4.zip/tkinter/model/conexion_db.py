import sqlite3


class ConexionDB:
    def __init__(self):
        #si existe accede a ella, sino la crea. 
        #abrimos conexión
        self.base_datos = 'database/tostadas_mayo.db'
        #para realizar la conexión 
        self.conexion = sqlite3.connect(self.base_datos) 
        #para realizar las instrucciones dentro de la base de datos
        self.cursor = self.conexion.cursor()

    def cerrar(self):
        #cerramos conexión 
        self.conexion.commit()
        self.conexion.close()